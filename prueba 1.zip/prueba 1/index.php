<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Prueba</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="styles/style.css">
  <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">

</head>
<body>
<!-- partial:index.partial.html -->
<header>
  <h1>Panel de Busqueda</h1>
  
  <form action="recibir.php" method="post" onsubmit="return validarBusqueda()">
    <label for="" style="display: none;">Search</label>
    <input class="search" type="text" name="user" id="busqueda" placeholder="Buscar" required>
    <input class="btn" type="submit" value="Buscar" style="width:90px;">
    <input class="btn clear" value="Clear" readonly>
  </form>
</header>



<footer>

</footer>
<!-- partial -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
  <script  src="scripts/script.js"></script>

</body>
</html>
<script>

function validarBusqueda() {
  var busqueda = document.getElementById("busqueda").value;
  if (busqueda.length < 4) {
    alert("La búsqueda debe tener un mínimo de 4 caracteres");
    return false;
  } else if (busqueda.toLowerCase() == "doublevpartners") {
    alert("No se permite la búsqueda de la palabra 'doublevpartners'");
    return false;
  }
  return true;
}
</script>