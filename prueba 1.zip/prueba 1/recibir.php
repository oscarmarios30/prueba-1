<?php

// URL de la API de Github
$url = 'https://api.github.com/search/users?q='.$_POST["user"];

// Opciones de solicitud HTTP GET
$options = [
  'http' => [
    'method' => 'GET',
    'header' => [
      'User-Agent: PHP'
    ]
  ]
];

// Realizar solicitud HTTP GET a la API
$response = file_get_contents($url, false, stream_context_create($options));

// Decodificar respuesta JSON
$data = json_decode($response, true);




?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title></title>
  <link rel="stylesheet" href="styles/table-style.css">
  <script src="https://use.fontawesome.com/30f376b520.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

</head>
<body>
<!-- partial:index.partial.html -->
<div class="container">
   <center><h1>Resultado de usuario  </h1></center>
   <center><a href="index.php">Volver</a></center>
      <div class="row">
      <div class="col-md-12">
        <div class="panel panel-primary">
          <div class="panel-heading">
            <h3 class="panel-title">Usuarios</h3>
            <div class="pull-right">
             
              <span class="clickable filter" data-toggle="tooltip" title="Toggle table filter" data-container="body">
                 Activar Filtro
                <i class="glyphicon glyphicon-filter"></i>
              </span>
            </div>
          </div>
          <div class="panel-body">
            <input type="text" class="form-control" id="dev-table-filter" data-action="filter" data-filters="#dev-table" placeholder="Filter Developers" />
          </div>
          <?php 
if ($data && isset($data['items'])) {


          ?>
          <table class="table table-hover" id="dev-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Usuario</th>
                <th>Opcion</th>
              </tr>
            </thead>
            <tbody>

              <?php 

// Mostrar resultados en la página web
  $count = 0; // Contador para el número de resultados mostrados
  foreach ($data['items'] as $item) {

              ?>
              <tr>
                <td><?php echo $item['id'] ?></td>
                <td><a href="<?php echo $item['html_url']; ?>" target="_blank"><?php echo $item['login'] ?></a></td>
                <td><a href="ver-user.php?user=<?php echo $item['login']; ?>"><i class="fa fa-eye" aria-hidden="true"></i></a></td>
              </tr>
           <?php
    $count++; // Incrementar el contador
    if ($count == 10) break; // Detener el ciclo después de imprimir los primeros 10 resultados
  }

            ?>  
            </tbody>
          </table>

          <?php
} else {
  echo 'No se encontraron resultados.';
}

          ?>
        </div>
      </div>
     
    </div>
  </div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- partial -->
  <script  src="scripts/table-script.js"></script>

</body>
</html>


