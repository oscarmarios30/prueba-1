<?php
$curl = curl_init();
$username = $_GET["user"];

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.github.com/users/$username",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_USERAGENT => "My PHP script",
  CURLOPT_HEADER => false,
));

$response = curl_exec($curl);
$user = json_decode($response, true);



curl_close($curl);


$url = "https://api.github.com/users/$username/followers";
$options = [
    'http' => [
        'user_agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
        'header' => [
            'Accept: application/vnd.github.v3+json',
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
        ]
    ]
];
$context = stream_context_create($options);
$data = file_get_contents($url, false, $context);

$followers = json_decode($data, true);
$count = count($followers);


?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title></title>
  <meta name="viewport"
      content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css'>
<link rel="stylesheet" href="styles/profile-style.css">
<link rel="stylesheet" href="styles/charts-style.css">


</head>
<body>
<!-- partial:index.partial.html -->

<div class="wrapper">
  <div class="profile-card js-profile-card">
    <div class="profile-card__img">
      <img src="<?php echo $user['avatar_url']; ?>" alt="profile card">
    </div>

    <div class="profile-card__cnt js-profile-cnt">
      <div class="profile-card__name"><?php echo $user["login"]; ?></div>
      <div class="profile-card__txt">id: <strong><?php echo $user["id"]; ?></strong></div>
      <div class="profile-card-loc">
        <span class="profile-card-loc__icon">
          <svg class="icon"><use xlink:href="#icon-location"></use></svg>
        </span>

        <span class="profile-card-loc__txt">
        <?php echo $user["location"]; ?>
        </span>
      </div>


        <div class="profile-card-inf__item">
          <div class="profile-card-inf__title"><?php echo $count; ?></div>
          <div class="profile-card-inf__txt">Following</div>
          <center><a href="index.php">Volver</a></center>
          <br>
          
          <div class="container">
         <div class="chart chart-bar chart-horizontal">
        <div class="metric" style="width:24%">Following <span class="metric-value"><?php echo $count; ?></span></div>
        </div>
  
</div>
        </div>



    
    </div>

   

  </div>

</div>



<!-- partial -->
  <script  src="scripts/profile-script.js"></script>

</body>
</html>
